// The Swift Programming Language
// https://docs.swift.org/swift-book

import Foundation
import Network

@main
struct SwiftLocalServer {
    static func main() {
        createListener()
    }

    private static func createListener() {
        do {
            let listener = try NWListener(using: .tcp, on: 8080)
            listener.newConnectionHandler = { newConnection in
                newConnection.start(queue: .main)
                newConnection.receive(minimumIncompleteLength: 1, maximumLength: 8192) { data, contentContext, isComplete, error in
                    if let data, let request = String(data: data, encoding: .utf8) {
                        print("Request received: \(request)")
                        let parsed = Parser.shared.parseRequest(request)
                        print("""
                                Parsed Request:

                                → Method: \(parsed.method)
                                → Path: \(parsed.path)
                                → Headers: \(parsed.headers)
                                → Body: \(parsed.body)
                        """)
                        Route(connection: newConnection).serve(to: parsed)
                    }
                }
            }

            listener.start(queue: .main)
            dispatchMain()
        } catch {
            print("Error from try-catch: ", error)
        }
    }
}

final class Parser {
    nonisolated(unsafe) static let shared = Parser()
    private init() {}

    func parseRequest(_ text: String) -> (method: String, path: String, headers: [String: String], body: String) {
        let lines = text.components(separatedBy: "\r\n")
        let requestLine = lines[0].split(separator: " ")
        let method = String(requestLine[0])
        let path = String(requestLine[1])

        var headers: [String: String] = [:]
        var body: String = ""
        var isBody = false

        for line in lines.dropFirst() {
            if line.isEmpty {
                isBody = true
                continue
            }

            if isBody {
                body += line
            } else {
                let parts = line.split(separator: ":")
                if parts.count > 2 {
                    headers[String(parts[0])] = parts[1].trimmingCharacters(in: .whitespaces)
                }
            }
        }
        return (method, path, headers, body)
    }
}

final class Route {
    typealias Payload = (method: String, path: String, headers: [String: String], body: String)

    let connection: NWConnection
    init(connection: NWConnection) {
        self.connection = connection
    }

    private var users: [User] = []

    func serve(to payload: Payload) {
        switch (payload.method, payload.path) {
        case ("GET", "/users"):
            sendJSON(users)

        case ("POST", "/users"):
            if let data = payload.body.data(using: .utf8),
               let newUser = try? JSONDecoder().decode(User.self, from: data) {
                users.append(newUser)
                sendJSON(newUser)
            }

        case ("GET", let p) where p.starts(with: "/users/"):
            let idStr = String(p.split(separator: "/")[1])
            if let id = UUID(uuidString: idStr),
               let found = users.first(where: { $0.id == id }) {
                sendJSON(found)
            } else {
                sendResponse(status: 404, body: "Not Found")
            }

        case ("DELETE", let p) where p.starts(with: "/users/"):
            let idStr = String(p.split(separator: "/")[1])
            if let id = UUID(uuidString: idStr),
               let idx = users.firstIndex(where: { $0.id == id }) {
                let removed = users.remove(at: idx)
                sendJSON(removed)
            }

        default:
            sendResponse(status: 404, body: "Not Found")
        }
    }

    func sendResponse(status: Int, body: String) {
        let response = """
    HTTP/1.1 \(status)
    Content-Type: text/plain
    Content-Length: \(body.utf8.count)
    
    \(body)
    """
        connection.send(content: response.data(using: .utf8), completion: .contentProcessed({_ in }))
    }

    func sendJSON<T: Codable>(_ value: T) {
        let body = try! JSONEncoder().encode(value)
        let header = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: \(body.count)\r\n\r\n"
        connection.send(content: header.data(using: .utf8)!, completion: .contentProcessed({_ in }))
        connection.send(content: body, completion: .contentProcessed({_ in }))
    }
}

struct User: Codable {
    let id: UUID
    var name: String
    var favorite: Bool
}
